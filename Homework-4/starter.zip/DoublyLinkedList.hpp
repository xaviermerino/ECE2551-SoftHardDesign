//
//  DoublyLinkedList.hpp
//  Netflix_1
//
//

#ifndef DoublyLinkedList_hpp
#define DoublyLinkedList_hpp

#include <stdio.h>
#include <stdexcept>

template <typename Type>
class DoublyLinkedList {

public:
    DoublyLinkedList();
    unsigned int size();
    bool isEmpty();
    void insert(Type& e);
    unsigned int find(Type& e);
    void erase(unsigned int index);
    void show();
    void sort();
    Type& getHead();
    Type& getTail();
    Type& operator[] (const unsigned int index);
    
private:
    struct Node {
        Type data;
        Node* prev;
        Node* next;
    };
    
    unsigned int n;
    Node* header;
    Node* trailer;
    
};

#endif /* DoublyLinkedList_hpp */
